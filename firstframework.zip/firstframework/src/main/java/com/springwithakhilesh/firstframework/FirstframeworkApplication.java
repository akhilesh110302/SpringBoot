package com.springwithakhilesh.firstframework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstframeworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstframeworkApplication.class, args);
	}

}
