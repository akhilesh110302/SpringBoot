package com.springwithakhilesh.firstframework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstframeworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
